=====
Usage
=====

To use MLBox in a project::

    import mlbox
