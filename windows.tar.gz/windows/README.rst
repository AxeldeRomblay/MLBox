MLBox, Machine Learning Box
===========================

MLBox is a powerful Automated Machine Learning python library. 


Installation
------------

$ cd dist/
$ pip install *.whl 



