History
=======

0.1.0 (2017-02-09)
------------------
* First non-official release.

0.1.1 (2017-02-23)
------------------
* add of several estimators : Random Forest, Extra Trees, Logistic Regression, ...
* improvement in verbose mode for reader.

0.1.2 (2017-03-02)
------------------
* add of dropout for entity embeddings.
* improvement in optimiser.

0.2.0 (2017-03-22)
------------------
* add of feature importances for base learners.
* add of leak detection.
* add of stacking meta-model.
* improvement in verbose mode for optimiser (folds variance).

0.2.1 (2017-04-26)
------------------
* add of feature importances for bagging and boosting meta-models.

0.2.2 (official release : 2017-06-13, available on branch "master")
-------------------------------------------------------------------
* update of dependencies (Keras 2.0,...).
* add of LightGBM model.

dev 0.2.3 (non stable version, available on branch "dev-2.3")
------------------------------------------------------------
* add of pipeline memory.

dev 0.3.0 (not available yet)
-----------------------------
* update for Python 3 version.
